const https = require('https');

const spotifyClientId = '996bc2c1c8d34b2ab8448a499f81a676';
const spotifyClientSecret = 'aadeb860e14440208c74be0d65410d9e';

function getSpotifyAccessToken(callback) {
  const spotifyAuthData = new URLSearchParams({
    grant_type: 'client_credentials',
  });

  const spotifyAuthOptions = {
    method: 'POST',
    hostname: 'accounts.spotify.com',
    path: '/api/token',
    headers: {
      'Authorization': 'Basic ' + Buffer.from(spotifyClientId + ':' + spotifyClientSecret).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  };

  const spotifyReq = https.request(spotifyAuthOptions, (res) => {
    let responseData = '';

    res.on('data', (chunk) => {
      responseData += chunk;
    });

    res.on('end', () => {
      if (res.statusCode === 200) {
        const responseJson = JSON.parse(responseData);
        const accessToken = responseJson.access_token;
        callback(null, accessToken);
      } else {
        callback(new Error('Failed to get Spotify access token'), null);
      }
    });
  });

  spotifyReq.on('error', (error) => {
    callback(error, null);
  });

  spotifyReq.write(spotifyAuthData.toString());
  spotifyReq.end();
}

function getTrendingTracks(callback) {
  getSpotifyAccessToken((err, accessToken) => {
    if (err) {
      callback(err, null);
      return;
    }

    const spotifyRequestOptions = {
      method: 'GET',
      hostname: 'api.spotify.com',
      path: '/v1/search?query=eminem&type=artist&locale=en-US%2Cen%3Bq%3D0.5&offset=20&limit=20',
      headers: {
        'Authorization': 'Bearer ' + accessToken,
      },
    };

    const spotifyReq = https.request(spotifyRequestOptions, (res) => {
      let responseData = '';

      res.on('data', (chunk) => {
        responseData += chunk;
      });

      res.on('end', () => {
        if (res.statusCode === 200) {
          const responseJson = JSON.parse(responseData);
          callback(null, responseJson);
        } else {
          callback(new Error('Failed to fetch trending tracks from Spotify API'), null);
        }
      });
    });

    spotifyReq.on('error', (error) => {
      callback(error, null);
    });

    spotifyReq.end();
  });
}

function getGeniusData(accessToken, callback) {
  const geniusRequestOptions = {
    method: 'GET',
    hostname: 'api.genius.com',
    path: '/search?q=eminem', // Replace with your desired query to Genius API
    headers: {
      'Authorization': 'Bearer ' + accessToken,
    },
  };

  const geniusReq = https.request(geniusRequestOptions, (res) => {
    let responseData = '';

    res.on('data', (chunk) => {
      responseData += chunk;
    });

    res.on('end', () => {
      if (res.statusCode === 200) {
        const responseJson = JSON.parse(responseData);
        callback(null, responseJson);
      } else {
        callback(new Error('Failed to make authenticated request to Genius API'), null);
      }
    });
  });

  geniusReq.on('error', (error) => {
    callback(error, null);
  });

  geniusReq.end();
}

module.exports = {
  getTrendingTracks,
  getGeniusData,
};
