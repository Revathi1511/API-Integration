const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
const { getTrendingTracks, getGeniusData } = require("./modules/trakt/api");

dotenv.config();
const app = express();
const port = process.env.PORT || 8888;

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");
app.use(express.static(path.join(__dirname, "public")));

app.get("/", async (request, response) => {
  try {
    getTrendingTracks((err, trendingTracks) => {
      if (err) {
        console.error("Error fetching trending tracks:", err.message);
        response.render("error", { title: "Error", message: "Failed to fetch trending tracks" });
      } else {
        console.log(trendingTracks);
        response.render("index", { title: "Trending Tracks", tracks: trendingTracks });
      }
    });
  } catch (error) {
    console.error("Error fetching trending tracks:", error.message);
    response.render("error", { title: "Error", message: "Failed to fetch trending tracks" });
  }
});

app.get("/trending-songs", async (request, response) => {
  try {
    // Replace 'YOUR_GENIUS_ACCESS_TOKEN' with the Genius access token you obtained earlier
    const geniusAccessToken = '3wL9l-8o-SM8WwID_ao91_yPtg2otMLVP0ZafXaMv14jK_xOwR3Fb-h7VwTtTnuM';
    getGeniusData(geniusAccessToken, (err, trendingSongs) => {
      if (err) {
        console.error("Error fetching trending songs:", err.message);
        response.render("error", { title: "Error", message: "Failed to fetch trending songs" });
      } else {
        response.render("trending-songs", { title: "Trending Songs", songs: trendingSongs });
      }
    });
  } catch (error) {
    console.error("Error fetching trending songs:", error.message);
    response.render("error", { title: "Error", message: "Failed to fetch trending songs" });
  }
});

app.listen(port, () => {
  console.log(`Listening on http://localhost:${port}`);
});
